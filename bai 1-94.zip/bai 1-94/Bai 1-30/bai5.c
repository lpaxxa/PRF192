#include <stdio.h>;
int main()
{
    int a;
    int b;
    printf("Enter a: ");
    scanf("%d",&a);
    printf("enter b: ");
    scanf("%d", &b);
    int t;
	t=a+b;
	printf("total: %d",t);
	return 0;
}

//int %d
//float %f
//double %lf
//char %c

