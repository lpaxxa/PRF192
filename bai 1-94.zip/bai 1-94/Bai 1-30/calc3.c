//	Calculate:	P(n)=1.3.5�(2.n+1),       n>=0
int main()
{
	int n,i;
	printf("enter n:");
	scanf("%d",&n);
	int p=1;
	for (i=1;i<=n;i++)
	{
		p=p*(2*i+1);
	}
	printf("p=%d",p);
	return 0;
}


//n=4 p= 1.3.5.7.9=945
//i=1 p=1.3
//i=2 p=1.3.5
//i=3 p=1.3.5.7
//i=4 p=1.3.5.7.9

