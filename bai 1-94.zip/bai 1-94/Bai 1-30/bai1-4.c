#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int main(int argc, char *argv[]) {
//	printf("Hello World");
//	printf("Le Phuong Anh");
//	printf("SE191147");
//	printf("SE1904");
//	printf("14/07/2005");
//	printf("0911407217");
//	int max =50;
//	int birthYear;
//	char firstName[max];
//	char lastName[max];
//	printf("enter firstname:");
//	fgets(firstName,sizeof(firstName),stdin);
//	fflush(stdin);
//	printf("enter lastname:");
//	fgets(lastName,sizeof(lastName),stdin);
//	lastName[strcspn(lastName, "\n")] = '\0'; 
//	firstName[strcspn(firstName, "\n")] = '\0'; 
//	printf("enter birth year:");
//	scanf("%d",&birthYear);
//	printf("%s %s %d",firstName,lastName,birthYear);
	
	//BAI 4
	
	printf("/******************************************************/\n");
	printf("/****************HUONG DAN CHEP TAP TIN****************/\n");
	printf("/=>B1. Vao thu muc\"C:\TUYEN TAP\"thotinh.txt            /\n");
	printf("/=>B2. Click chuot phai vao tap tinh thotinh.txt       /\n");
	printf("/=>B3. Chon copt tu menu tat                           /\n");
	printf("/=>B4. Chon vi tri can luu, click chuot phai chon paste/\n");
	printf("/*****************************************************/\n");
	

	return 0;
	
}
