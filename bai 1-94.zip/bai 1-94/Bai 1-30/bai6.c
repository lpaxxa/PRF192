#include <stdio.h>;
int main()
{
    float a, b, c;
   
    printf("Enter a, b: ");
     scanf("%f %f", &a, &b);
	c=a/b;
	printf("quotient: %.2f",c);
	
	return 0;
}

//+ = add
//- = minus
//* = muliply
// / = divide
// % = remainders
//adddrress and value
