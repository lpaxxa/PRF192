#include<stdio.h>
int main()
{
	int a;
	printf("enter a number:");
	scanf("%d",&a);
	if (a%2==0)
	printf("the number is even");
	else 
	printf("the number is odd");
	return 0;
}
//% takes the number after the decimal 5%2=2.5
// / takes the number bef
