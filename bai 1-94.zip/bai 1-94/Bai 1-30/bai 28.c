// Write a program to input a three-digit integer n. Output to the screen in ascending order of digits. 
#include <stdio.h>

int main() {
    int num;
    int max,min,med;

    printf("Enter a three-digit integer: ");
    scanf("%d", &num);

    int digit1 = num / 100;
    int digit2 = (num / 10) % 10;
    int digit3 = num % 10;
    if(digit1>digit3  && digit1>digit2&& digit2>digit3 )
    {
    	
    		
    			max=digit1;
    			med=digit2;
    			min=digit3;
			
		
    }
    else if(digit2>digit1 && digit2>digit3 && digit1>digit3)
    {
    	
    			max=digit2;
    			med=digit1;
    			min=digit3;
    			
	}
	else if(digit3>digit1 && digit3>digit2 && digit1>digit2)
	{
		        max=digit3;
		        med=digit1;
    			min=digit2;
	}
	else
	{
		max=digit3;
		med=digit2;
		min=digit1;
	}
	

    printf("Digits in ascending order: %d %d %d\n", min,med,max);

    return 0;
}


