#include<stdio.h>
int main()
{
	int a,b;
	printf("enter a:");
	scanf("%d",&a);
	printf("enter b:");
	scanf("%d",&b);
	if (a>b){
		printf("%d",a);
	}else{
		printf("%d",b);
	}
	
	return 0;
}
