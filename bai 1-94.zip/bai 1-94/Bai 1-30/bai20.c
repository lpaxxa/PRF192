//input a,b; find the largest number using conditional operator.
#include<stdio.h>
int main()
{
	int a,b,max;
	printf("enter a,b:");
	scanf("%d%d",&a,&b);
	printf("%d",a>b?a:b);
//	if 
//	(a>b)
//	max=a;
//	else 
//	max=b;
//printf("%d",max);

return 0;
}
