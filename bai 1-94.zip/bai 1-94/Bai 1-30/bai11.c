#include<stdio.h>
int main()
{
	float F,C;
	printf("enter C:");
	scanf("%f",&C);
	F=(C*(float)9/5)+32;
	printf("%f",F);
	return 0;
}

