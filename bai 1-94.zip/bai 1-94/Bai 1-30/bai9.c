#include<stdio.h>
int main()
{
	float a,b,c;
	printf("enter a:");
	scanf("%f",&a);
	printf("enter b:");
	scanf("%f",&b);
	c=a/b;
	printf("%.2f",c);
	return 0;
}
