
//	Calculate:	S(n)=1+3+5+?.+(2�n+1),       n>=0
#include<stdio.h>
int main()
{
	int n,i;
	printf("enter n:");
	scanf("%d",&n);
	int s=1;
	for(i=1;i<=n;i++)
	{
		s=s+(2*i+1);
	}
	printf("s=%d",s);
	return 0;
	
}

//n=4. s=1+3+5+7+9=25
//i=2 s=1+3
