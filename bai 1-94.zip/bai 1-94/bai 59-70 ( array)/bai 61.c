//61.	Write a program in C to find the first even number in an array. If the array has no even numbers, print the first value of the array.
#include<stdio.h>
#include<stdlib.h>
void input(int a[], int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("INPUT a[%d]:", i);
		scanf("%d",&a[i]);
}
}
void output(int a[], int n){
	int i;
	for (i=0; i<n;i++)
	{
		printf("%d ",a[i]);
	}
}
void Even(int a[], int n)
{
	
	int i;
	for (i=0; i<n; i++){
		if(a[i]%2 == 0)
		{
			printf("%d ", a[i]);
		return;
		}
	}
		printf("%d ", a[0]);
		
}


int main()
{
    int a[10];
	int n;
	printf("enter an array of number:");
	scanf("%d", &n);
	input(a,n);
	output(a,n);
	printf("\n");
	Even(a,n);
    return 0;
}
