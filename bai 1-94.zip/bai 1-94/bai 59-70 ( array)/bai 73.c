//73.	Write a program in C to sort elements of the array in ascending order.
#include<stdio.h>
void input(int a[], int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("Input [%d]:",i);
		scanf("%d", &a[i]);
	}
}
void output(int a[], int n)
{
	int i; 
	for(i=0;i<n;i++)
	{
		printf("%d",a[i]);
	}
}
void AscendingArray(int a[], int n)
{
	int i;
	int j;
	int t;
	for(i=0;i<n;i++){
	for(j=i+1;j<n;j++)
	{	
		if (a[i]>a[j])
		{
		
		t=a[i];
		a[i]=a[j];
		a[j]=t;
	}
	}
	printf("%d",a[i]);
	}
}
int main()
{
	int n;
	int a[50];
	printf("input: ");
	scanf("%d", &n);
	input(a,n);
	output(a,n);
	printf("\n");
	AscendingArray(a,n);
	return 0;
}
