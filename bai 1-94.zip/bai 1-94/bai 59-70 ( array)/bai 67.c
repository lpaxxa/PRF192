//67.	Write a program in C to find the sum of all elements of the array
#include<stdio.h>
void input(int a[], int n)
{
	int i;
	for(i=0;i<n;i++){
	
	printf("input [%d]:",i);
	scanf("%d", &a[i]);
}
}
void output(int a[], int n)
{
	int i;
	for(i=0;i<n;i++){
		printf("%d",a[i]);
	}
}
void Sum(int a[], int k)
{
	int i;
	int sum=0;
	for(i=0;i<k;i++)
	{
		sum+=a[i];
		
	}printf("%d",sum);
	
	}

int main()
{
	int n;
	int a[50];
	printf("input:");
	scanf("%d",&n);
	input(a,n);
	output(a,n);
	printf("\n");
	Sum(a,n);
	return 0;
}
