//60.	Write a program in C to find the minimum element in an array
#include<stdio.h>
#include<stdlib.h>
void input(int a[], int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("input[%d]:", i);
		scanf("%d", &a[i]);
	}
}
void output(int a[], int n){
	int i;
	for (i=0; i<n;i++)
	{
		printf("%d ", a[i]);
	}
}
void MinVa(int a[], int n)
{
	int min = a[0];
	int i;
	for (i=0; i<n; i++){
		if (a[i] < min)
		{
		min=a[i];
		}
	}printf("%d", min);
	
	
}

int main()
{
    int a[50];
	int n;
	printf("enter an array of number:");
	scanf("%d", &n);
	input(a,n);
	output(a,n);
	printf("\n");
	MinVa(a,n);
return 0;
}
