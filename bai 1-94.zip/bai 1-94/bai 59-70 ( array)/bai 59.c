//59.	Write a program in C to find the maximum element in an array
#include<stdio.h>
#include<stdlib.h>
void input(int a[], int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("input[%d]:",i);
		scanf("%d", &a[i]);
	}
}
void output(int a[], int n){
	int i;
    int	kq= MaxVa(a,n);
	for (i=0; i<n;i++)
	{
		printf("%d ", a[i]);
	}
}
void MaxVa(int a[], int n)
{
	int max=a[0];
	int i;
	for (i=1; i<n; i++){
		if (a[i]>max){
			max=a[i];
		}
	}printf("%d", max);
	
}

int main()
{
	int a[50];
	int n;
	printf("enter an array of number:");
	scanf("%d", &n);
	input(a,n);
    output(a,n);
    printf("\n");
    MaxVa(a,n);
	return 0;
}
