//66.	Write a program in C to count all odd numbers in array
#include<stdio.h>
void input(int a[], int n)
{
	int i;
	for(i=0;i<n;i++){
	
	printf("input [%d]:",i);
	scanf("%d", &a[i]);
}
}
void output(int a[], int n)
{
	int i;
	for(i=0;i<n;i++){
		printf("%d",a[i]);
	}
}
void Odd(int a[], int k)
{
	int i;
	int count=0;
	int sum=0;
	for(i=0;i<k;i++)
	{
		if (a[i]%2==1)
		{
		count++;
		
	}
	
	}
	if (count>0)
	printf("%d",count);
}
int main()
{
	int n;
	int a[50];
	printf("input:");
	scanf("%d",&n);
	input(a,n);
	output(a,n);
	printf("\n");
	Odd(a,n);
	return 0;
}
