//69.	Write a program in C to find the average of all prime numbers of the array.
#include<stdio.h>
void input(int a[], int n)
{
	int i;
	for(i=0;i<n;i++){
	
	printf("input [%d]:",i);
	scanf("%d", &a[i]);
}
}
void output(int a[], int n)
{
	int i;
	for(i=0;i<n;i++){
		printf("%d",a[i]);
	}
}
int isPrime(int n)
{
	int i;
	int count=0;
	for(i=1;i<=n;i++)
	{
		if (n%i==0)
		count++;
	}
	if (count==2)
           return 1;
           
    else
           return 0;
}
void Average(int a[], int k)
{
	int i;
	float avg=0;
	int sum=0;
	int count=0;
	for(i=0;i<k;i++)
	{
		if(isPrime(a[i])==1)
		{
		sum+=a[i];
		count++;
        }
        if(count>0)
        {
        	avg=(float)sum/count;
		}

    }	printf("%.2f",avg);
	}

int main()
{
	int n;
	int a[50];
	printf("input:");
	scanf("%d",&n);
	input(a,n);
	output(a,n);
	printf("\n");
	Average(a,n);
	return 0;
}
