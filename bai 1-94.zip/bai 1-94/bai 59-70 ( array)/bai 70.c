//70.	 Write a program in C input a integer number x. Find the first index of x in the array. If array has not x, return -1.
#include<stdio.h>
void input(int a[], int n)
{
	int i;
	for(i=0;i<n;i++){
	
	printf("input [%d]:",i);
	scanf("%d", &a[i]);
}
}
void output(int a[], int n)
{
	int i;
	for(i=0;i<n;i++){
		printf("%d",a[i]);
	}
}
int FirstIndex(int a[], int n)
{
	int i;
	int x;
	printf("enter an interger:");
	scanf("%d",&x);
	for(i=0;i<n;i++)
	{
		if(a[i]==x)
		return i;
	
		
	}
		return -1;
}
int main()
{
	int n;
	int a[50];
	printf("input:");
	scanf("%d",&n);
	input(a,n);
	output(a,n);
	printf("\n");
	int x=FirstIndex(a,n);
	// if having to print out NO instead of -1
	if(x==-1)
	printf("NO");
	else
	printf("%d", x);
	return 0;
}
