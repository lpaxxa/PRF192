//64.	Write a program in C to find the last prime number in an array. If the array has no prime numbers, print the last value of the array.
#include<stdio.h>
#include<stdlib.h>

void input(int a[], int n)
{
	int i;
	for (i=0;i<n;i++)
	{
		printf("nhap a[%d]: ",i);
		scanf("%d",&a[i]);
	}
}

void output(int a[], int n)
{
	int i;
	for (i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
}
int isPrime(int k)
{
	int i;
	int count=0;
	for (i=1;i<=k;i++)
	{
		if (k%i==0)
		count++;
	}
	if (count==2)
	return 1;
	else return 0;
}
void Prime(int a[], int n)
{
	int i;
	
	for(i=n-1;i>=0;i--)
	{
		if(isPrime(a[i])==1)
		{
		
		printf("%d", a[i]);
		return;
		
	    }
	
	}  
		printf("%d",a[n-1]);
		
	}
	
int main()
{
	int n;
	int a[50];
	printf("input:");
	scanf("%d",&n);
	input(a,n);
	output(a,n);
	printf("\n");
	Prime(a,n);
	return 0;
}
