//63.	Write a program in C to find the last odd number in an array. If the array has no odd numbers, print the last value of the array.
#include<stdio.h>
#include<stdlib.h>
void input(int a[], int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("INPUT a[%d]:", i);
		scanf("%d", &a[i]);
	}
}
void output(int a[], int n)
{
	int i;
	for(i=0;i<n;i++){
		printf("%d",a[i]);
	}
}

void LastOdd(int a[], int n)
{

	int i;
	
	for (i=n-1; i>=0; i--){
		if(a[i] % 2 != 0)
		{		
		printf("%d ",a[i]);
		return;
		}
		
    } 
	printf("%d ", a[n-1]);
}


int main()
{
    int a[50];
	int n;
	printf("enter an array of number:");
	scanf("%d", &n);
	input(a,n);
	printf("\n");
	LastOdd(a,n);
    return 0;
}
