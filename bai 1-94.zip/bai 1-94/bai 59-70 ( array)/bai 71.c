//71.	Write a program in C to read n number of values in an array and display it in reverse order
#include<stdio.h>
void input(int a[], int n)
{
	int i;
	for(i=0;i<n;i++){
	
	printf("input [%d]:",i);
	scanf("%d", &a[i]);
}
}
void output(int a[], int n)
{
	int i;
	for(i=0;i<n;i++){
		printf("%d ",a[i]);
	}
}
void Value(int a[], int n)
{
	int i;
	for(i=n-1;i>=0;i--)
	{
		printf("%d ",a[i]);
	}
}
int main()
{
	int n;
	int a[50];
	printf("input:");
	scanf("%d",&n);
	input(a,n);
	output(a,n);
	printf("\n");
	Value(a,n);
	return 0;
}
