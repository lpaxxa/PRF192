// 72. Write a program to find the index of the 2nd prime number in the array.
// If the array has only 1 prime number, the index of the first prime number is returned.
// If the array does not have a prime number, the first value of the array is returned.
#include<stdio.h>
void Input(int a[], int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("a[%d]:",i);
		scanf("%d", &a[i]);
	}
}
void Output(int a[], int n)
{
	int i;
	for(i=0; i<n;i++)
	{
		printf("%d ", a[i]);
	}
}
int isPrime( int k)
{
	int i;
	int count=0;
	for(i=1;i<=k;i++)
	{
		if (k%i==0)
		count++;
	}
	if (count==2)
        return 1;
    else
        return 0;
}
int Index(int a[], int n)
{
	int i;
	int count=0;
	int temp;
	int flag=0;
	for(i=0;i<n;i++)
	{
		if(isPrime(a[i])==1)
		{
		count++;
		}
		if (count==2)
		{
			printf("%d ",i);
			return;
		}
		if(count==1 && flag==0)
		{
			temp=i;
		    flag=1;
		}
		
	}
	if(count==1)
	    printf("%d ",temp);
	if(count==0)
	    printf("%d ",a[0]);
		    
}
int main()
{
	int n;
	int a[50];
	printf("input:");
	scanf("%d",&n);
	Input(a,n);
	Output(a,n);
	printf("\n");
	Index(a,n);
	return 0;
}
