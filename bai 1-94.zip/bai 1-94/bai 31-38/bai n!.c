//Calculate: 	 n!   (n>0) 
#include<stdio.h>
int main()
{
	int n;
	int i;
	int s=1;
	printf("enter n:");
	scanf("%d",&n);
	for (i=1;i<=n;i++);
	{
		s=s*i;
	}
	printf("s=%d",s);
	return 0;
}
