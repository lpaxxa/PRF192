//Calculate: 	S(n)=1+1/2+1/3+?+1/n,      n>0  
#include<stdio.h>
int main()
{
//	int n,i;
//	printf("enter n:");
//	scanf("%d",&n);
//	float s=0.0;
//	for(i=1;i<=n;i++)
//	{
//		s+=(float)1/i;
////		printf("s=%",s);
//		
//	}
//	printf("s=%.2f\n",s);
	
	//While Loop//
//	int n;
//	printf("enter n:");
//	scanf("%d",&n);
//	int i=1;
//	float s=0.0;
//	while(i<=n)
//	{
//		s+=(float)1/i;
//		i++;
//		
//		
//	}
//printf("s=%.2f\n",s);

    int i=1;
    float s=0;
    int n;
    do
    {
    	printf("enter n:");
    	scanf("%d",&n);
    	s+=(float)1/i;
    	i++;
    	printf("s=%.2f\n",s);
	}while (i<=n);
	return 0;
}
//n=3. s= 1+1/2 +1/3
//i=1.. s= 1
//i=2. s= 1+1/2
//i=3. s=1+1/2 +1/3
