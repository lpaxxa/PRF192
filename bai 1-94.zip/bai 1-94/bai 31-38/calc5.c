//Calculate:	S(n)=1-2+3-4+?+(-1)^(n+1) n,   n>0
#include<stdio.h>
#include<math.h>
int main()
{
//	int n,i,t;
//	printf("enter n:");
//	scanf("%d",&n);
//	int s=0;
//	for (i=1;i<=n;i++)
//	{
//		
//		t=pow((-1),i+1);
//		s=s+t*i;
//	
//	}
//	printf("s=%d\n",s);

    //while//

//    int i=1;
//    int t;
//    int s=0;
//    int n;
//    printf("enter n:");
//    scanf("%d",&n);
//    while(i<=n)
//    {
//    	t=pow((-1),i+1);
//    	s=s+t*i;
//    	i++;
//	}
//		printf("s=%d\n",s);

    //do-while
    int i=1;
    int t,n;
    int s=0;
    do{
    	printf("enter n:");
    	scanf("%d",&n);
    	t=pow((-1),i+1);
    	s=s+t*i;
    	i++;
	}while(i<=n);
	printf("s=%d",s);
	return 0;
}
//n=3 s= 1-2+3=2
//i=1 s= 1
//i=2 s=1-2
//i=3 s=1-2+3
