//Calculate:	S(n)=1+1.2+1.2.3+?+1.2.3�.n,        n>0)
#include<stdio.h>
int main()
{
	
    int n;
        printf("enter n:");
        scanf("%d",&n);
    int i;
    int t=1;
    int s=0;
    for(i=1;i<=n;i++)
   {
	t=t*i;
	s=s+t;
    }
printf("s=%d",s);
return 0;
}

//n=4. s=1+1.2+1.2.3+?+1.2.3.4=33
//i=1 t= 1.1=1 s=0+1=1
//i=2 t=1.2 s=1+1.2


