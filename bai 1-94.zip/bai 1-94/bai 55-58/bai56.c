//56.	Write a program in C to print all odd numbers in array.
#include<stdio.h>
void Nhapmang(int a[], int n)
{
	int i;
	for (i=0;i<n;i++)
	{
		printf("nhap a[%d]: ",i);
		scanf("%d",&a[i]);
	}
}

void Xuatmang(int a[], int n)
{
	int i;
	for (i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
}

void Xuatle(int a[], int n)
{
	int i;
	for(i=0;i<n;i++){
	
	if (a[i]%2==1)
	printf("%d ",a[i]);
    }
}
int main(){
	int a[50];
	int n;
	printf("input n: ");
	scanf("%d",&n);
	Nhapmang(a,n);
	Xuatmang(a,n);
	printf("\n");
	Xuatle(a,n);
	return 0;
}
