//57.	Write a program in C to print all prime numbers in array.
#include<stdio.h>
#include<stdbool.h>


void Nhapmang(int a[], int n)
{
	int i;
	for (i=0;i<n;i++)
	{
		printf("input a[%d]:",i);
		scanf("%d",&a[i]);
	}
}
void Xuatmang(int a[], int n)
{
	int i;
	for (i=0; i<n;i++)
	{
		printf("%d ",a[i]);
	}
}
bool isPrime(int k){
	int i;
	int count=0;
	for (i=1;i<=k;i++)
	{
	    if (k%i==0)
	    count++;
	}
	if(count==2)
	   return true;
	   else
	   return false;
}
void xuatisPrime(int a[], int n)
{
	int i;
	for (i=0;i<n;i++)
	{
	if(isPrime (a[i])==true)
	printf("%d ", a[i]);
    }
}

int main()
{
	int a[50];
	int n;
	printf("input n: ");
	scanf("%d",&n);
	Nhapmang(a,n);
	Xuatmang(a,n);
	printf("\n");
	xuatisPrime(a,n);
	return 0;
}
