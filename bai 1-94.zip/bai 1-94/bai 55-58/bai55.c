//55.	Write a program in C to print all even numbers in array
//nhap mang
#include<stdio.h>
void Nhapmang(int a[], int n)
{
	int i;
	for (i=0;i<n;i++)
	{
		printf("nhap a[%d]: ",i);
		scanf("%d",&a[i]);
	}
}

void Xuatmang(int a[], int n)
{
	int i;
	for (i=0;i<n;i++)
	{
		printf("%d",a[i]);
	}
}

void Xuatchan(int a[], int n)
{
	int i;
	for(i=0;i<n;i++){
	
	if (a[i]%2==0)
	printf("%d ",a[i]);
    }
}
int main(){
	int a[50];
	int n;
	printf("input n: ");
	scanf("%d",&n);
	Nhapmang(a,n);
	Xuatmang(a,n);
	printf("\n");
	Xuatchan(a,n);
	return 0;
}

