//50.	Write a program in C to add two numbers using pointers.
#include<stdio.h>
int main()
{
	int a,b,s;
	printf("enter two numbers:");
	scanf("%d %d", &a,&b);
	int *pa=&a;
	int *pb= &b;
	 s= *pa +*pb;
	 printf("%d",s);
	 return 0;
}

