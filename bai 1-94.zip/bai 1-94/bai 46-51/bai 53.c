//53.	Write a program in C to swap 2 elements using call by reference.
#include<stdio.h>
void swap(int *n1, int *n2)
{
	int t;
	t= *n1;
	*n1 = *n2;
	*n2 = t;
	printf("the swapped functions are:\n%d %d",*n1,*n2 );
}
int main()
{
	int f1,f2;
	printf("enter 2 elements:");
	scanf("%d%d",&f1,&f2);
	swap(&f1,&f2);
//	
	return 0;
}
