//52.	Write a program in C to find the maximum number between two numbers using a pointer.
#include<stdio.h>
int main()
{
	int a,b, *ma= &b,*mb= &a, max;
	printf("input 2 numbers: ");
	scanf("%d %d",&a,&b);
	if(*ma>*mb){
		printf("%d",*ma);
	}else
	printf("%d",*mb);
	return 0;
}
