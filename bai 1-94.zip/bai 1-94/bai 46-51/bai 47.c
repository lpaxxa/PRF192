//47.	Write a program in C to convert a decimal number to a binary number using the function.
#include<stdio.h>

float dectoBinary(int decimal)
{
	
	int binary=0;
	int remainder,i=1;
	while(decimal!=0){
		remainder=decimal%2;
		decimal=decimal/2;
		binary += remainder * i;
        i *= 10;
	}
	return binary;

}

int main(){
	int n,i, kq,binary;
	printf("enter a decimal: ");
	scanf("%d",&n);
	binary=dectoBinary(n);
	printf("%d", binary);
	return 0;
	
}
