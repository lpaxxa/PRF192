//49.	Write a C program to input a positive integer n. Print all �perfect numbers� less than n.
#include<stdio.h>
#include<stdbool.h>
bool isPerfect(int n){
	int i;
	int s=0;
	for(i=1;i<n;i++){
		if(n%i==0)
		s+=i;
	}
	if (s==n){
	
	return true;
}
	else
	return false;
	
}
void printPerfect(int n){
	int i;
	for (i=1;i<n;i++)
	    if (isPerfect(i))
	    printf("%d\n",i);
}
int main()
{
	int n;
	printf("enter a number:");
	scanf("%d",&n);
	printPerfect(n);
	return 0;
}
