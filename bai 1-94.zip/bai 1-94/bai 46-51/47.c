//47.	Write a program in C to convert a decimal number to a binary number using the function.
#include<stdio.h>

void dectoBinary(int n)
{
	int nBinary[1000];
	int i=0;
	while(n>0){
		nBinary[i]=n%2;
		n=n/2;
		i++;
	}

}

int main(){
	int n,i;
	for(int j = i - 1; j >= 0; j--) 
	
    printf("%d", nBinary[j]); 
	printf("enter a decimal");
	scanf("%d",&n);
	return 0;
	
}
