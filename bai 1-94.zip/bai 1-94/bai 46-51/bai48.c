//48.	Write a program in C to check whether a number is �perfect numbers� or not using the function.
//(Perfect numbers: a perfect number is a positive integer that is equal to the sum of its positive divisors, excluding the number itself)
//Ex: 6 = 1+2+3 (6 is perfect number)
//		28=1+2+4+7+14 (28 is perfect number)
#include<stdio.h>
#include<stdbool.h>
bool isPerfect(int n){
int i;
int s=0;
   for(i=1;i<n;i++){
if(n%i==0)
s+=i;
}
if(s==n){
return true;
}
else
return false;
}

int main()
{
	int n,s,i;
	printf("enter a number\n");
	scanf("%d",&n);
    if (isPerfect(n)){
	printf("this is a perfect number");
}
	else
	printf("this is not a prime number");



	return 0;

}
