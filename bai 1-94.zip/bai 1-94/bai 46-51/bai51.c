//51.	Write a program in C to add numbers using call by reference.
#include<stdio.h>
int addNumbers(int*n1, int *n2){
	int sum;
	sum= *n1 +*n2;
	return sum;
}
int main()
{
	int fn,sn,sum;
	printf("enter 2 numbers:\n");
	scanf("%d%d",&fn, &sn);
	sum= addNumbers(&fn,&sn);
	printf("the numbers are: %d %d\n\n",fn,sn);
	printf("sum=%d\n",sum);
	return 0;
}
