//Write a program in C to swap two numbers using a function. 
#include<stdio.h>
int main()
{
	int a,b;
	printf("enter a,b\n");
	scanf("%d %d",&a, &b);
	int *pa=&b;
	int *pb=&a;
	
	printf("a=%d b=%d",*pa,*pb);
	
	return 0;
}
