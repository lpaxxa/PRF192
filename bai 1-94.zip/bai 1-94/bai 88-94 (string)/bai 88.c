//88.	Write a C program to find total number of alphabets, digits or special character in a string.
#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
int CountAlpha(char str[] )
{
    int count=0;
    int i;
    for(i=0; str[i];i++)
    {
    	if (isalpha(str[i]))
    	{
    		count++;
		}
	}
	return count;
}
int CountDigit(char str[] )
{
    int count=0;
    int i;
    for(i=0; str[i];i++)
    {
    	if (str[i]>='0' && str[i]<='9')
    	{
    		count++;
		}
	}
	return count;
}
int main()
{
	char str[100];
	int alpha,digit;
	printf("enter a string: ");
    gets(str);
	
	alpha= CountAlpha(str);
	digit=CountDigit(str);
	printf("alpha=%d\ndigit=%d",alpha, digit);
	
	return 0;
}
