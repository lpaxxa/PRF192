//90.	Write a C program to count total number of words in a string.
#include<stdio.h>
#include<ctype.h>
#include<string.h>
int CountWord(char str[])
{
	int i;
	int count=0;
	for(i=0;str[i];i++)
	{
		if (str[i]=='\t' || str[i]=='\n' || str[i]==' ')
		{
			count++;
		}
		
	}
	if(i>0)
		count++;
	return count;
}
int main()
{
	int str[100];
	printf("input string: ");
	gets(str);
	int word=CountWord(str);
	printf("%d",word);
	return 0;
}
