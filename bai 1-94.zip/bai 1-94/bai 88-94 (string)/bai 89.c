//89.	Write a C program to count total number of vowels and consonants in a string.
#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
int CountVowel(char str[] )
{
    int count=0;
    int i;
    for(i=0; str[i]!='\0';i++)
    {
    	if (str[i]=='a' || str[i]=='e' || str[i]=='i' || str[i]=='o' || str[i]=='u' )
    	{
    		count++;
		}
	}
	return count;
}
int CountConsonant(char str[] )
{
    int count=0;
    int i;
    for(i=0; str[i]!='\0';i++)
    {
    	if (str[i]!='a' && str[i]!='e' && str[i]!='i' && str[i]!='o' && str[i]!='u' && str[i]!=' ' )
    	{
    		count++;
		}
	}
	return count;
}
int main()
{
	char str[100];
	int vowel,consonant;
	printf("enter a string: ");
    gets(str);
	
	vowel= CountVowel(str);
	consonant=CountConsonant(str);
	printf("vowel=%d\nconsonant=%d",vowel,consonant);
	
	return 0;
}
