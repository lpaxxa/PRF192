//92.	Write a C program to reverse order of words in a given string.
#include<stdio.h>
#include<ctype.h>
#include<string.h>

//32- space in ASCII
void ReverseWord( char str[])
{
	int i;
	int size=strlen(str);
	char tmp[100]="";
	char result[100]="";
	int sizetmp=strlen(tmp);
	strrev(str);
	for(i=0; i<size; i++)
	{
		if(str[i]!=32)
		{
			tmp[sizetmp]=str[i];
			sizetmp++;
		}
		if(str[i]==32 || i==size-1)
		{
			tmp[sizetmp]='\0';
			strrev(tmp);
			strcat(result,tmp);
			strcat(result," ");
			strcpy(tmp,"");
			sizetmp=0;
		}
	}
	
	 result[strlen(result) - 1] = '\0';
		strcpy(str,result);
	printf("%s",str);
}
int main()
{
	char str[1000];
	printf("input string: ");
	gets(str);
	ReverseWord(str);
	return 0;
}

