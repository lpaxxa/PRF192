//94.	Write a C program to find last occurrence of a character in a given string.
#include<stdio.h>
#include<ctype.h>
#include<string.h>
void FindChar(char str[], char character)
{
	int i;


	int len=strlen(str);
	for(i=len-1;i>0;i--)
	{
		if(str[i] == character){
			printf("\npos: %d", i);
			break;
		}
	}
	

}
int main()
{
	char str[100];
	int n;
	printf("input string:");
	gets(str);
	char character;
	printf("enter a character:");
	scanf("%c",&character);
	FindChar(str, character);
	return 0;
}

