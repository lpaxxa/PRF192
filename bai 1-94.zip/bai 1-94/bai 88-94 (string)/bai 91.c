//91.	Write a C program to find reverse of a string.
#include<stdio.h>
#include<string.h>

void StringReverse(char str[])
{
	int i;
	int j;
	int len = strlen(str);
//	for ( i = 0, j = len - 1; i <= j; i++, j--) {
//		
//			char temp=	str[i];
//			str[i]=str[j];
//			str[j]=temp;
//		}

//or


strrev(str);
	printf("%s", str);

}
int main()
{
	char str[1000];
	printf("input string: ");
	gets(str);
	StringReverse(str);
	return 0;
}

